<?php include_once 'include/header.php'; ?>
<br>
<br>
<section class="vehicle-sorter-area section-padding">
	<div class="section-title text-center">
				<h2>
					<span>Cars Available In Mumbai</span>
				</h2>
			</div>
<div class="container">
<div class="vehicle-sorter-wrapper mix-it-gallery">

<div class="row ">
<br>
<br>
	<div class="col-md-6 col-sm-6 mix party Sedancar">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="car.php"><img src="img/car_use/vento.png" alt=""></a>
							</div>
							<h3>Volkswagen Vento</h3>
							<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 4 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div></div></div>

<div class="col-md-6 col-sm-6 mix party suvcars">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="car.php"><img src="img/car_use/Xuv500.png" alt=""></a>
							</div>
							<h3>Mahindra XUV500</h3>
							<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 5 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div></div></div>


<div class="col-md-6 col-sm-6 mix suvcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/car_use/innova.png" alt=""></a>
</div>
<a href="#"><h3>Innova Crysta</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Innova" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>





	<div class="col-md-6 col-sm-6 mix party suvcars">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="car.php"><img src="img/car_use/creta.png" alt=""></a>
							</div>
							<h3>Hyundai Creta</h3>
							<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

						
						</div>
					</div>




</div>

</div>
</div>
</section>	



<?php include_once 'include/footer.php'; ?>

