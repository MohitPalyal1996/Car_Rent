<?php include 'include/header.php'; ?>
<script src="js/country.js"></script>
<?php 
$message= $_GET['message'];
?>

<section class="inner-banner">
<div class="container text-center">
<h2><span>Book Now</span></h2>

</div>
</section>

<section class="call-to-action" style="padding-top: 8px; text-align: center; color: white;">
<div class="container">
<div class="row">
<div class="col-md-12">
<h3><b>Booking <?php echo $message; ?></b></h3>		
</div>
<div class="col-md-3">
</div>
</div>
</div>
</section>

<div class="container-fluid" style="padding-top: 80px;">  
<div class="row">
<!-- </s><div style="text-align: center;"><h3>Booking <?php echo $massage; ?></h3></div> -->
<div class="col-sm-12 col-md-12">
<div class="tariff">
<div class="tariff-header bg-dr-blue-2">

<!-- <div class="tariff-title color-white"><h3>Booking</h3></div> -->
</div>

<div class="tariff-content bg-white">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12" id="form-content">
<form class="book" action="sub.php" method="POST" id="book"> 
<fieldset>

<div class="form-group col-md-4">
<input type="hidden" class="form-control" id="booking1" name="booking" value="<?php echo $massage; ?>">
</div>
<br>


<div class="form-group col-md-4">
<label >Name <sup>*</sup></label>
<input type="text" class="form-control" id="name" name="name" required="" placeholder="Enter the Name">
</div>
<div class="form-group col-md-4">
<label >Email-ID <sup>*</sup></label>
<input type="email" class="form-control" id="email" name="email" required="" placeholder="Enter the Email">
</div>
<div class="form-group col-md-4">
<label >Mobile <sup>*</sup></label>
<input type="tel" class="form-control" id="mob" name="mob" required="" placeholder="Enter the Mobile No." pattern="[789][0-9]{9}" required="">
</div>
<div class="clear-fix"></div>
<div class="form-group col-lg-4" reqired="">
<label >Country <sup>*</sup></label>
<select class="form-control" id="country" name="country" required="">
</select>
</div>

<div class="form-group col-lg-4">
<label >State <sup>*</sup></label>
<select class="form-control" name="state" id="state" required="">
</select>
</div>

<script language="javascript">
populateCountries("country", "state");
populateStates("state");
</script>

<div class="form-group col-md-4">
<label >City <sup>*</sup></label>
<input type="text" class="form-control" id="city" name="city" required="" placeholder="Enter the City" required="">
</div>
<div class="clear-fix"></div>

<div class="form-group col-md-4">
<label >Date of Arrival <sup>*</sup></label>
<input placeholder="Date of Arrival" class="textbox-n form-control" type="text"   id="datea" name="datea" required="">
</div>
<div class="form-group col-md-4">
<label >Date of Departure <sup>*</sup></label>
<input placeholder="Date of Departure" class="textbox-n form-control" type="text"  id="dated" name="dated" required="">
</div>

<div class="form-group col-md-4">
<label >Travel City : <sup>*</sup></label>
<input type="text" class="form-control" id="t_city" name="t_city" placeholder="Enter the City" required="">
</div>
<div class="clear-fix"></div>

<!-- <div class="form-group col-md-4">
<label>Children (5-12 Yr)</label>
<select class="form-control" id="child" name="child">
<option>Children</option>
<option>0</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
</select>
</div> -->

<div class="form-group col-md-4">
<label>The Fleet : </label>
<select class="form-control" id="acc" name="acc">
<option><b>--Select Vehicle--</b></option>
<option>Audi Q6</option>
<option>Audi Q7</option>
<option>Swift Dzire</option>
<option>Toyota Etios</option>
<option>Indigo</option>
<option>Honda City</option>
<option>Nissan Sunny</option>
<option>Honda Accord</option>
<option>Toyota Camry</option>
<option>Toyota Corolla</option>
<option>Toyota Corolla</option>
<option>MBMW5</option>
<option>Mercedes E 220</option>
<option>Mercedes S 350</option>
<option>Mercedes Viano</option>
<option>Toyota Innova</option>
<option>Toyota Parado</option>
<option>Toyota Fortuner</option>
<option>Nissan Urvan</option>
<option>Limousine</option>
<option>38 Seater Volvo with Washroom </option>
<option>44 Seater Volvo </option>
<option>Mitsubishi Rosa</option>
<option>Toyota Commuter</option>
<option>Toyota Coaster</option>
<option>Fiat Ducato</option>
<option>Volkswagen Crafter</option>
<option>Mercedes Coach</option>
<option>Tempo Traveller 9 Seater</option>
<option>Tempo Traveller 10 Seater</option>
<option>Tempo Traveller 11 Seater</option>
<option>Tempo Traveller 12 Seater</option>
<option>Tempo Traveller 13 Seater</option>
<option>Tempo Traveller 14 Seater</option>
<option>Tempo Traveller 15 Seater</option>
<option>Tempo Traveller 16 Seater</option>
</select>
</div>

<div class="form-group col-md-4">
<label>Address <sup>*</sup></label>
<!-- <input type="text" class="form-control" id="mob" name="add" required="" placeholder="Enter your Address" -->
<textarea class="form-control" id="add" name="add" required="" placeholder="Enter your Address"></textarea>
</div>

<div class="form-group col-md-4">
<label>Other Requirement : </label>
<textarea class="form-control" rows="4" id="comment" name="comment" placeholder="Additional Information" style="height: 71px;"></textarea>
</div>
<div class="form-group col-md-12">
<?php
if(isset($_SESSION['flash_msg_c'])) :  

echo $_SESSION['flash_msg_c'];

unset($_SESSION['flash_msg_c']);
endif;
?>
<div class="g-recaptcha" data-sitekey="6LeuQE4UAAAAANyGhgYWasmuZpKFbxV06Lgo9k57" >

</div>
</div>
<div class="form-group col-md-12">

<button type="submit" name="submit_b" id="submit_b" class="btn btn-warning btn-lg submit_b" >Submit</button>
</div>
</fieldset>
</form>


</div>
</div>
</div>








<!-- <div class="detail-wrapper">
<div class="main-wraper">
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-12" id="form-content" >
<form class="contact-form js-contact-form"  id="book" method="post">
<div class="row">

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="text" name="name" required="" id="name" placeholder="Enter your Name">
</div>
</div>

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="email" name="email" required="" id="email" placeholder="Enter your Email">
</div>
</div>

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="text" name="mob" required="" id="mob" placeholder="Enter Mobile Number">
</div>
</div>

<div class="col-xs-12 col-sm-4">
<div class="drop-wrap drop-wrap-s-3 color-2">
<div class="drop"> 
<select id="country" name="country"><i class="fa fa-angle-down"></i></select>  
</div>
</div>
</div>


<div class="col-xs-12 col-sm-4">
<div class="drop-wrap drop-wrap-s-3 color-2">
<div class="drop"> 
<select name="state" id="state"><i class="fa fa-angle-down"></i></select>
</div>
</div>
</div>



<script language="javascript">
populateCountries("country", "state");
populateStates("state");
</script>

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="text" name="city" required="" id="city" placeholder="Enter the City">
</div>
</div>


<div class="col-xs-12 col-sm-6">
<div class="input-style-1 type-2 color-2">
<input placeholder="Date of Arrival" class="textbox-n" type="date"   id="datea" min="23-03-2018" name="datea"></div>
</div>

<div class="col-xs-12 col-sm-6">
<div class="input-style-1 type-2 color-2">
<input placeholder="Date of Departure" class="textbox-n" type="text" onfocus="(this.type='date')"  id="dated" name="dated"></div>
</div>

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="number" name="adult" required="" id="adult" placeholder="Adult">
</div>
</div>

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="number" name="child" required="" id="child" placeholder="Children (5-12 Yr)">
</div>
</div>

<div class="col-xs-12 col-sm-4">
<div class="input-style-1 type-2 color-2">
<input type="text" name="acc" required="" id="acc" placeholder="Accommodation">
</div>
</div>
-->


<!-- <div class="col-xs-12 col-sm-6">
<div class="input-style-1 type-2 color-2">
<input type="number" name="noday" id="noday" required="" placeholder="Number of Days">
</div>
</div>
-->
<!-- <div class="col-xs-12 col-sm-12">
<div class="input-style-1 type-2 color-2">
<input type="text" name="add1" id="add1" required="" placeholder="Address 1">
</div>
</div>
-->
<!-- <div class="col-xs-12 col-sm-12">
<div class="input-style-1 type-2 color-2">
<input type="text" name="add2" id="add2" required="" placeholder="Address 2">
</div>
</div>
-->

<!-- <div class="col-xs-12">
<textarea class="area-style-1 color-1" required="" id="comment" name="comment" placeholder="Additional Information"></textarea>
<button type="submit" id="submit" name="submit" class="btn btn-warning btn-lg c-button small bg-dr-blue-2 hv-dr-blue-2-o" style="font-size: 16px;">Submit</button>
</div>
</div>
</form>
--><!-- *********************************************************** -->
<!-- </div>
</div>
</div>
</div>

</div>
-->

<!-- ============================================================================================================ -->

</div>
</div>
</div>  
</div>
</div>



<!-- MAP BLOCK -->
<div class="map-block">
<iframe  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3216.5992365993598!2d80.04205281418862!3d12.823087221590685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a52f712b82a78d9%3A0xfdb944a3aee53831!2sSRM%20Institute%20of%20Science%20and%20Technology!5e1!3m2!1sen!2sin!4v1617784849061!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>




<!-- *********************************************************** -->


<?php include 'include/footer.php'; ?>

<script type="text/javascript">
$(document).ready(function() {  

$('#form-content').on('submit',function(){
//Prevent Default Submission
$.ajax({
url: 'sub.php',
type: 'POST',
data: $('#book').serialize(),
beforeSend: function()
{ 
$('#submit_b').attr('disabled',true);
$("#submit_b").html('Submitting ...');
} // it will serialize the form data
})
.done(function(data){
$('#form-content').fadeOut('slow', function(){
$('#form-content').fadeIn('slow').html(data);
});
})
.fail(function(){
alert('Ajax Submit Failed ...');  
});
return false;
});

});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#datea").datepicker({
minDate:0,
numberOfMonths: 1,
onSelect: function(selected) {
$("#dated").datepicker("option","minDate", selected)
}
});
$("#dated").datepicker({ 
minDate:0,
numberOfMonths: 1,
onSelect: function(selected) {
$("#datea").datepicker("option","maxDate", selected)
}
});  
});
</script>