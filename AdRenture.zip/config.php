<?php
session_start();
$con=mysqli_connect("localhost","root","","adrenture");
// Check connection
// Check connection
// if (!$con) {
//   die("Connection failed: " . mysqli_connect_error());
// }
// echo "Connected successfully";




define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'http://localhost/Adrenture/');
define('SITE_PATH','http://localhost//Adrenture/');

?>