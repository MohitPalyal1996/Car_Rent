<?php include_once 'include/header.php'; 
?>
<link rel="stylesheet" type="text/css" href="js/custom.js">
<section class="inner-banner" style=" background: #000 url(img/AdRenture_Home_page.jpeg) center center no-repeat;height: 400px;">
		<div class="container text-center">
			<h2><span>Contact Us</span></h2>
		</div>
	</section>


	
	<section class="latest-news contact-page section-padding contact-page-two blog-2-col blog-3-col blog-page">
		<div class="container">
			<div class="row">
				
				<div class="col-md-12 ">
					<div class="container-fluid">
            <div class="row">
            <div class="col-lg-6" id="form-content">

            <form class="contact-form js-contact-form" action="send_message.php" method="POST" id="book"> 
            <fieldset>

            <div class="form-group col-md-6">
            <label >Name <sup>*</sup></label>
            <input type="text" class="form-control" id="name" name="NAME" required="" placeholder="Enter the Name">
            </div>
            <div class="form-group col-md-6">
            <label >Email-ID <sup>*</sup></label>
            <input type="email" class="form-control" id="email" name="EMAIL" required="" placeholder="Enter the Email">
            </div>
        
             <div class="form-group col-md-6">
            <label >Mobile <sup>*</sup></label>
            <input type="tel" class="form-control" id="monile" name="MOBILE" required="" placeholder="Enter the Mobile No." pattern="[789][0-9]{9}" required="" style="width: 530px;">
            </div>

            <div class="form-group col-md-12">
            <label>Other Requirement : </label>
            <textarea class="form-control" rows="4" id="comment" name="COMMENT" placeholder="Additional Information" style="height: 121px;width: 530px;"></textarea>
            </div>



            <div class="form-group col-md-12" style="line-height: 105px;"> 

            <button type="Submit" name="Submit" value="Submit" class="btn btn-warning btn-lg" >Submit</button>
            </div>
            </fieldset>
            </form>
				</div>
			
		
	 <div class="col-lg-6">
	<iframe style="width:100%; height:420px; border:none" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3216.5992365993598!2d80.04205281418862!3d12.823087221590685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a52f712b82a78d9%3A0xfdb944a3aee53831!2sSRM%20Institute%20of%20Science%20and%20Technology!5e1!3m2!1sen!2sin!4v1617784849061!5m2!1sen!2sin">
		
</iframe>
</div>
</div>
</div></div>
</div>
	</section>

<?php include_once 'include/footer.php'; ?>

<!-- <script type="text/javascript">
	function send_message(){
	var NAME=jQuery("#NAME").val();
	var EMAIL=jQuery("#EMAIL").val();
	var MOBILE=jQuery("#MOBILE").val();
	var COMMENT=jQuery("#COMMENT").val();
	
	if(NAME==""){
		alert('Please enter NAME');
	}else if(EMAIL==""){
		alert('Please enter EMAIL');
	}else if(MOBILE==""){
		alert('Please enter MOBILE');
	}else if(COMMENT==""){
		alert('Please enter COMMENT');
	}else{
		jQuery.ajax({
			url:'send_message.php',
			type:'post',
			data:'NAME='+NAME+'&EMAIL='+EMAIL+'&MOBILE='+MOBILE+'&COMMENT='+COMMENT,
			success:function(result){
				alert(result);
			}	
		});
	}
}


</script> -->