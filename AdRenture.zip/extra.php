<?php 
include 'configg.php';
 ?>

 <p>
<?php if(isset($_SESSION['name'])){
                                          echo "Welcome, ". htmlspecialchars ($_SESSION['name']); 
                                        }else{
                                            echo '<a href="login.php">Login/Register</a>';
                                        }
                                        ?></a> </p>
<p>
<a href="">
<?php if(isset($_SESSION['name'])){
                                            echo '<a href="logout.php">Logout</a>';
                                        }else{
                                            echo '';
                                        }
                                        ?>
</p>