<?php include_once 'include/header.php'; ?>
<section class="inner-banner">
		<div class="container text-center">
			<h2><span>Frequently Asked Question</span></h2>
		</div>
	</section>



	<section class="latest-news section-padding blog-2-col blog-3-col blog-page faq-page">
		<div class="container">
			<div class="row">
				<div class="col-md-3 pull-right">
					<div class="sidebar-widget-wrapper">
						<div class="single-sidebar-widget popular-categories">
							<div class="title">
								<h3><span>Popular Categories</span></h3>
							</div>
							<ul class="link-list">
								<li><a href="#">
									<span>Party Bus </span>
									<span class="count">(04)</span>
								</a></li>
								<li><a href="#">
									<span>Muscle Car </span>
									<span class="count">(08)</span>
								</a></li>
								<li><a href="#">
									<span>Long Drive Vheicle </span>
									<span class="count">(07)</span>
								</a></li>
								<li><a href="#">
									<span>Sport Edition </span>
									<span class="count">(10)</span>
								</a></li>
								<li><a href="#">
									<span>Luxury Car </span>
									<span class="count">(12)</span>
								</a></li>
							</ul>
						</div>
						<div class="single-sidebar-widget latest-post-widget">
							<div class="title">
								<h3><span>latest news</span></h3>
							</div>
							<ul class="latest-post">
								<li><a href="#">
									<div class="img-box">
										<img src="img/resources/latest-post-sidebar-1.jpg" alt="">
									</div>
									<div class="content">
										<h3>stet clita ea et gubergren, kasd magna no rebum</h3>
										<p class="text-right">
											<i class="fa fa-calendar"></i>
											14th jan, 2016
										</p>
									</div>
								</a></li>
								<li><a href="#">
									<div class="img-box">
										<img src="img/resources/latest-post-sidebar-2.jpg" alt="">
									</div>
									<div class="content">
										<h3>stet clita ea et gubergren, kasd magna no rebum</h3>
										<p class="text-right">
											<i class="fa fa-calendar"></i>
											14th jan, 2016
										</p>
									</div>
								</a></li>
								<li><a href="#">
									<div class="img-box">
										<img src="img/resources/latest-post-sidebar-3.jpg" alt="">
									</div>
									<div class="content">
										<h3>stet clita ea et gubergren, kasd magna no rebum</h3>
										<p class="text-right">
											<i class="fa fa-calendar"></i>
											14th jan, 2016
										</p>
									</div>
								</a></li>
							</ul>
						</div>
						<div class="single-sidebar-widget flicker-widget">
							<div class="title">
								<h3><span>Gallery</span></h3>
							</div>
							<ul class="list-inline">
								<li><a href="#"><img src="img/resources/f-gallery-1.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-2.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-3.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-4.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-5.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-6.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-7.jpg" alt="Awesome Image"/></a></li>
								<li><a href="#"><img src="img/resources/f-gallery-8.jpg" alt="Awesome Image"/></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-9 pull-left">
					<div class="faq-box">
						<div class="title">
							<h3><span>Frequently Asked Questions</span></h3>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit possimus numquam magnam quisquam quia dolorem labore deserunt, voluptate provident debitis officia accusamus impedit perspiciatis unde vero, aliquid repudiandae hic quas.</p>						
						<br>
						<div class="accrodion-grp" data-grp-name="faq-accrodion">
							<div class="accrodion active">
								<div class="accrodion-title">
									<h4>Lorem ipsum dolor sit amet, consetetur sadipscing</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion ">
								<div class="accrodion-title">
									<h4>Duis autem vel eum iriure dolor in hendrerit in vulputate</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion">
								<div class="accrodion-title">
									<h4>Vel illum dolore eu feugiat nulla facilisis</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion ">
								<div class="accrodion-title">
									<h4>Duis autem vel eum iriure dolor in hendrerit in vulputate</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion">
								<div class="accrodion-title">
									<h4>Vel illum dolore eu feugiat nulla facilisis</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion ">
								<div class="accrodion-title">
									<h4>Duis autem vel eum iriure dolor in hendrerit in vulputate</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion">
								<div class="accrodion-title">
									<h4>Vel illum dolore eu feugiat nulla facilisis</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion ">
								<div class="accrodion-title">
									<h4>Duis autem vel eum iriure dolor in hendrerit in vulputate</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
							<div class="accrodion">
								<div class="accrodion-title">
									<h4>Vel illum dolore eu feugiat nulla facilisis</h4>
								</div>
								<div class="accrodion-content">
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   </p>
								</div>
							</div>
						</div>						
					</div>
					<ul class="post-pagination text-center">
						<li><span>01</span></li>
						<li><a href="#">02</a></li>
						<li><a href="#">03</a></li>
						<li><a href="#">04</a></li>
						<li><a href="#">05</a></li>
						<li><a href="#">06</a></li>
						<li><a href="#">07</a></li>
						<li><a href="#">08</a></li>
						<li><a href="#">09</a></li>
						<li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</section>


<?php include_once 'include/footer.php'; ?>