<?
include 'config.php';
if (!isset($_SESSION['Name'])) {
// echo "You are logged out";
//  header('Location: login.php');

}


 ?>



<ul class="navigation list-inline" style="line-height: 80px;">

<li > <a href=""><?php if(isset($_SESSION['Name'])){
                                           echo "Welcome, ". htmlspecialchars ($_SESSION['Name']);  
                                        }else{
                                            echo '<a href="login.php">Login/Register</a>';
                                        }
                                        ?></a></li>


<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'active'; }else { echo ''; } ?>"><a href="contact.php">Contact Us</a></li>
<!-- <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'our_coaches.php'){echo 'active'; }else { echo ''; } ?>"><a href="our_coaches.php">Our Coaches</a></li> -->

<li><a href="">
<?php if(isset($_SESSION['Name'])){
                                            echo '<a href="logout.php">Logout</a>';
                                        }else{
                                            echo 'log';
                                        }
                                        ?></a>
</li>

</ul>