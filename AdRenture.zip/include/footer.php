<footer class="footer">
		<div class="container">
			<div class="row">
				
				
				<div class="col-md-4 col-sm-6">
					<div class="footer-widget post-widget">
						<div class="title">
							<h2><span>Important links</span></h2>
						</div>
						<ul>
							<li><a href="index.php"><i class="fa fa-angle-right"></i>Home</a></li>
							<!-- <li><a href="testimonial.php"><i class="fa fa-angle-right"></i>Testimonial Page</a></li> -->
							<li><a href="profile.php"><i class="fa fa-angle-right"></i>Profile</a></li>						
							<li><a href="terms&condition.php"><i class="fa fa-angle-right"></i>Terms & Condition</a></li>
							<li><a href="policy.php"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
							<li><a href="contact.php"><i class="fa fa-angle-right"></i>Contact Us</a></li>
						</ul>
					</div>									
				</div>
				
				<div class="col-md-4 col-sm-6">
					<div class="footer-widget contact-widget">
						<div class="title">
							<h2><span>contact info</span></h2>
						</div>
						<ul class="contact-infos">
							<br>
							<li>
								<div class="icon-box">
									<i class="fa fa-map-marker"></i>
								</div>
								<div class="info-text">
									<p>SRM Chennai (India)</p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-phone"></i>
								</div>
								<div class="info-text">
									<p>Office nos : 91-123456,7890122</p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-phone"></i>
								</div>
								<div class="info-text">
									<p>24 hours Mobile : +91-1234567890 </p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-phone"></i>
								</div>
								<div class="info-text">
									<p>24 hours Mobile : +91-12121223455</p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-envelope"></i>
								</div>
								<div class="info-text">
									<p>E Mail : Adrenture@gmail.com, Adrenture@Info.com</p>
								</div>
							</li>
							<br>
						
							<a href="#" class="logotext">ADRENTURE</a>
						</ul>
					</div>
				</div>



				<!-- <div class="col-md-3 col-sm-6">
					<div class="footer-widget post-widget">
					<iframe src="//www.google.com/maps/embed/v1/place?q=Japmeet Holidays,
      					&zoom=17
      					&key=AIzaSyDW9N4qIukHL_RvEYiXTpdkO40KwZBX7nE">
 					 </iframe>
					</div>									
				</div> -->
					<div class="col-md-4 col-sm-6">
					<div class="footer-widget post-widget">
						<div class="title" >
							<h2><span>Quick Support</span></h2>
						</div>
						<br>
						<!-- <div class="col-md-4">
							<h5>India Tour</h5>
						</div>
						<div class="col-md-4"> 
							<img src="img/members/iato.jpg">
						</div>
						<div class="col-md-4">
							<img src="img/members/itta.jpg">
						</div>
						<div class="clearfix"></div><br> -->
						
						<div class="members" style="margin-top: 2%;">
							
							<div class="col-md-12" class="txt"> 
<i class="fa fa-whatsapp fa-2x" style="color: white; "></i> <p style="color: white;     display: inline-block;vertical-align: super;padding-left: 10px;"><a href="https://wa.me/919971178437" target="_blank" style="color: white;">+91-9988998899</a></p><br>
							</div>
							<div class="clearfix"></div>

							
							<div class="col-md-12" class="txt"> 
							<i class="fa fa-mobile fa-2x" style="color: white;    "></i>	<p style="color: white;  display: inline-block;
    vertical-align: super;
    padding-left: 10px;">+91-9999999999</p>
							</div>
							<div class="clearfix"></div>
							
							<div class="col-md-12" class="txt"> 
								<i class="fa fa-phone fa-2x" style="color: white; "></i> <p style="color: white;  display: inline-block;
    vertical-align: super;
    padding-left: 10px;">011-9988998/40</p>
							</div>
							<div class="clearfix"></div><br>
							<div class="col-md-4">
								<p style="color: white;"><span>Email:Adrenture@Info.com <br>Adrenture@Info.com</span></p>
							</div>
						</div>
						
					</div>									
				</div>

				<div class="clearfix"></div>



			</div>
		</div>
	</footer>

	<section class="bottom-bar">
		<div class="container">
			<div class="text pull-left">
			<div id="google_translate_element"></div>	</div>
			<div class="social pull-right">
				<ul class="list-inline">
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
					<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
					<li><a href="#"><i class="fa fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>
	</section>




	<!-- Modal -->
	
			
		
	


	<script src="assets/jquery/jquery-1.11.3.min.js"></script>
	<!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha384-xBuQ/xzmlsLoJpyjoggmTEz8OWUFM0/RC5BsqQBDX2v5cMvDHcMakNTNrHIW2I5f" crossorigin="anonymous"></script>
 -->
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>

	<script src="http://maps.google.com/maps/api/js"></script>
	<script src="assets/gmap.js"></script>
	<script src="assets/validate.js"></script>

	<!-- Revolution slider JS -->
	<script src="assets/revolution/js/jquery.themepunch.tools.min.js"></script> 
	<script src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>

	<script src="assets/owl.carousel-2/owl.carousel.min.js"></script>

	<!-- jQuery ui js -->
	<script src="assets/jquery-ui-1.11.4/jquery-ui.js"></script>


	<!-- mixit up -->
	<script src="assets/jquery.mixitup.min.js"></script>
	<!-- fancy box -->
	<script src="assets/fancyapps-fancyBox/source/jquery.fancybox.pack.js"></script>



	<!-- custom.js -->

	<script src="js/map-script.js"></script>
	<script src="js/default-map-script.js"></script>
	<script src="js/custom.js"></script>
<!-- 	<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script> -->
	<!-- <script src="js/loadMoreResults.js"></script> -->


</body>

<!-- Mirrored from world5.commonsupport.com/html/genurent/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 16 Feb 2018 15:01:37 GMT -->
</html>