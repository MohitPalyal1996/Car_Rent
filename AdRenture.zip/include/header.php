<?
include 'config.php';
if (!isset($_SESSION['Name'])) {
// echo "You are logged out";
//  header('Location: login.php');

}


 ?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'AdRenture'; }

elseif(basename($_SERVER['SCRIPT_NAME']) == 'testimonial.php'){echo 'Testimonial'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'profile.php'){echo 'Profile'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'our_cars.php'){echo 'Our Cars'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'our_coaches.php'){echo 'Our Coaches'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'faq.php'){echo 'FAQ'; } 
elseif(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'Contact Us'; } ?> </title>
<!-- mobile responsive meta -->
<meta name="viewport" content="width=device-width, initial-scale=1">


<!-- main stylesheet -->
<link rel="stylesheet" type="text/css" href="css/custom.css">
<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="css/responsive.css">


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><link rel="stylesheet" href="assets/hover">
<link rel="stylesheet" href="assets/animate.min">
<link rel="stylesheet" href="assets/revolution/css/settings">
<link rel="stylesheet" href="assets/owl.carousel-2/assets/owl.carousel">
<link rel="stylesheet" href="assets/owl.carousel-2/assets/owl.theme.default.min">
<link rel="stylesheet" href="assets/Stroke-Gap-Icons-Webfont/style">
<link rel="stylesheet" href="assets/jquery-ui-1.11.4/jquery-ui">
<link rel="stylesheet" href="assets/fancyapps-fancyBox/source/jquery.fancybox">



<script src='https://www.google.com/recaptcha/api.js'></script>

<body id="body">

<header class="stricky">
<div class="container">

<div class="logo pull-left">
<a href="index.php" class="logotext">
AdRenture
</a>
</div>
<nav class="mainmenu-holder pull-right">
<div class="nav-header">
<ul class="navigation list-inline" style="line-height: 80px;">

<li > <a href=""><?php if(isset($_SESSION['Name'])){
                                           echo "Welcome, ". htmlspecialchars ($_SESSION['Name']);  
                                        }else{
                                            echo '<a href="login.php">Login/Register</a>';
                                        }
                                        ?></a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'active'; }else { echo ''; } ?>"><a href="index.php">Home</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'profile.php'){echo 'active'; }else { echo ''; } ?>"><a href="profile.php">Profile</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'our_cars.php'){echo 'active'; }else { echo ''; } ?>"><a href="our_cars.php">Our Cars</a></li>

<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'active'; }else { echo ''; } ?>"><a href="contact.php">Contact Us</a></li>
<!-- <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'our_coaches.php'){echo 'active'; }else { echo ''; } ?>"><a href="our_coaches.php">Our Coaches</a></li> -->

<li><a href="">
<?php if(isset($_SESSION['Name'])){
                                            echo '<a href="logout.php">Logout</a>';
                                        }else{
                                            echo 'log';
                                        }
                                        ?></a>
</li>

</ul>
</div>
<div class="nav-footer">
<ul class="list-inline">
<li class="menu-expander hidden-lg hidden-md"><a href="#"><i class="icon icon-List"></i></a></li>
</ul>
</div>
</nav>
</div>
</header>