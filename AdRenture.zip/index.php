<?php include_once 'include/header.php'; ?>
<script src="js/country.js"></script>
<div class="container-fluid" style="height: 900px; width: 100%" >

		<div class="row">
			
	<img src="img/AdRenture_Home_page.jpeg"  alt=""  width="100%" height="900" style="overflow: hidden;">
		
<h1 style="margin-top: -650px;text-align:center;font-weight: 700;font-size: 45px;
color: black;
font-family:latin;word-spacing: 1px;letter-spacing: 1px;">SAIL INTO YOUR NEW RIDE</h1>

<p style="text-align:center;font-weight: 200;font-size: 25px;
color: black;
font-family:latin;word-spacing: 1px;letter-spacing: 1px;" >Car Rental Service In And Around India's metropolitan cities</p>
	</div>
</div>

		
 <section class="latest-news section-padding">
		<div class="container">
			<div class="section-title text-center">
				<h2>
					<span>CHOOSE YOUR LOCATION</span>
					
				</h2>
			</div>
			<div class="row">
				<div class="col-md-3">
					<div class="single-blog-post" >
						<div class="img-box">
							<img src="img/city/Mumbai.jpg" alt="" height="220"  width="350" >
								<div class="box">
							<h1 id="cityh1" >
							Mumbai
						</h1 >
						<button id="citybutton" class="btn btn-danger"><a style="color: white" href="Mumbai.php">Book Now</a></button>
					</div>

						</div>

					</div>
				</div>
					<div class="col-md-3">
					<div class="single-blog-post" >
						<div class="img-box">
							<img src="img/city/bangalore.webp" alt="" height="220" width="350" >
								<div class="box">
							<h1 id="cityh1" >
							Bangalore
						</h1 >
						<button id="citybutton" class="btn btn-danger"><a style="color: white" href="Bangalore.php">Book Now</a></button>
					</div>

						</div>
					</div>
				</div>
						<div class="col-md-3">
					<div class="single-blog-post" >
						<div class="img-box">
							<img src="img/city/Chennai.jpg" alt="" height="220"  width="350">
								<div class="box">
							<h1 id="cityh1" >
							Chennai
						</h1 >
						<button id="citybutton" class="btn btn-danger"><a style="color: white" href="Chennai.php">Book Now</a></button>
					</div>

						</div>
					</div>
				</div>
						<div class="col-md-3">
					<div class="single-blog-post" >
						<div class="img-box">
							<img src="img/city/Hyderabad.jpeg" alt="" height="220"  width="350">
								<div class="box">
							<h1 id="cityh1" >
							Hyderabad
						</h1 >
						<button id="citybutton" class="btn btn-danger"><a style="color: white" href="Hyderabad.php">Book Now</a></button>
					</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section> 
 <section class="welcome-section section-padding">
		<div class="container">
			<div class="section-title text-center">
				<h2>
					<span>welcome to  hire Luxury car</span>
				</h2>
				
		    </div>
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="single-welcome">
						<div class="top-box">
							<div class="icon-box">
								<img src="img/icon/1.png" alt="">
							</div>
							<div class="content-box">
								<h3>Car dealer number one world wide</h3>
							</div>
						</div>
						<p>AdRenture is a company started by 2 aspiring computer science enthusiasts currently in their second year who aim to prepare any sort of itineraries which give you unlimited opportunity to organize, select and book the type of Car that is attractive to you and your clients. Above all, these are itineraries with utmost respect for your money and can also be modified to suit the individual requirements. True to its name, AdRenture ensures that every ride with us truly turns out to be an exciting Adventure!!!.</p>
						<br>
						<!-- <p>Adrenture, was founded in XXXX as a Luxury Tourist Transport Operator. Adrenture owned and operated the largest fleet of imported luxury cars and coaches in the country. our all vehicles are immaculately maintained & driven by experienced, courteous and well mannered uniformed chauffeurs having operational mobile phone with them.</p> -->
					</div>
				</div>
				<div class="clearfix"></div>
				
			</div>
		</div>
	</section>


<?php include_once 'include/footer.php'; ?>
