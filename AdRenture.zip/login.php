<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Login From</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>
:root {
  --input-padding-x: 1.5rem;
  --input-padding-y: .75rem;
}



body {
background-color:#F5F5DC;

}

.card-signin {
  border: 0;
/*  border-radius: 1rem;*/
  box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
}

.card-signin .card-title {
 padding-top: 20px;
  font-weight: 300;
  font-size: 1.5rem;

}



.card-signin .card-body {
   height: 580px;
}

.form-signin {
  width: 100%;
}

.form-signin .btn {
  font-size: 80%;
  
 font-weight: 500;

  transition: all 0.2s;
}

.form-label-group {
  position: relative;
  margin-bottom: 1rem;
}

.form-label-group input {
  height: auto;
  border-radius: 0.5rem;
}

.form-label-group>input,
.form-label-group>label {
  padding: var(--input-padding-y) var(--input-padding-x);
}



/* Fallback for Edge
-------------------------------------------------- */

@supports (-ms-ime-align: auto) {
  .form-label-group>label {
    display: none;
  }
  .form-label-group input::-ms-input-placeholder {
    color: #777;
  }
}

/* Fallback for IE
-------------------------------------------------- */

@media all and (-ms-high-contrast: none),
(-ms-high-contrast: active) {
  .form-label-group>label {
    display: none;
  }
  .form-label-group input:-ms-input-placeholder {
    color: #777;
  }

}

.fa {
  
  font-size: 15px;
  width: 18px;
  text-align: center;
  text-decoration: none;

  border-radius: 50%;
}
.fa:hover {
    opacity: 1;
    color: white;
}
.fa-facebook {
  background: #3B5998;
  padding-top: 2px;
  color: white;
 margin-bottom: -5px;
 
}

.fa-google {

padding: 2px 2px;
  text-decoration: none;
background: #dd4b39;
  color: white;
 
}



#password {
  background-image: url("https://img.icons8.com/material-sharp/20/000000/visible.png");
  background-position: 96%  bottom;
background-size: 30px;
  background-repeat: no-repeat;
 
}
#password.visible {
  background-image: url("https://img.icons8.com/material-outlined/20/000000/invisible.png");

}

#toggle-password {
 
 height:50px;
 width: 50px;
display: none;
 margin-top: -112px;
}

#toggle-password + label {
  text-indent: -9999px;
  display: inline-block;
  width: 20px;
  height: 20px;
  margin-left: 260px;
  margin-top: -140px;
  cursor: pointer;
}

#bimg{
 background:url(img/background.jpg);
 background-position: center;
 background-repeat: no-repeat;
}




</style>

</head> 
<body id="bimg" > 
                  <div class="container" >
    <div class="row" style="margin-top: -21px; " >
      <div class="col-sm-8 col-md-6 col-lg-4 mx-auto" >
        <div class="card card-signin" style="background-color: white;">
    <h5 class="card-title text-center"><a href="index.php"><i  class="fa fa-angle-left" aria-hidden="true" style="float: left;color:black;margin-left: 20px;font-size: 30px;"></i></a><p style="font-weight: 400;margin-right: 20px;">Sign in</p></h5>
          <div class="card-body">
            <label style=""><b style="font-weight: 300px;">Email</b></label>
            <form class="form-signin needs-validation" action="logincont.php" method="POST">
              <div class="form-label-group">
  <input type="email" id="inputEmail" name="Email" placeholder="name@example.com" required  class="form-control" 
  value="<?php if(isset($_COOKIE['emailcookie']))
  { 
    echo $_COOKIE['emailcookie'];
}
?>">
                
              </div>
              <span class="field_error" id="login_email_error"></span>
 <label style=""><b style="">Password</b></label>
              <div class="form-label-group">
                 <input type="password" id="password" name="Password" name="password" value="<?php if(isset($_COOKIE['passwordcookie'])){ echo $_COOKIE['passwordcookie'];}?>" class="form-control" placeholder="Password" required />
             <input type="checkbox" id="toggle-password" >
             <label for="toggle-password"></label>


   
      <a href="#" style="float: right;color: black;margin-top: -20px;">Forget password?</a> 

  </div>
      <span class="field_error" id="login_password_error"></span>
    <div class="form-group ">
      <input type="checkbox" name="rememberme" > Remember Me
    </div>
<br>
          
     


                       <button class="btn btn-lg " type="submit"  name="submit"  style="width: 100%;background-color:black;color: white;padding: 11px;">Sign in</button>
              </form>
              <br>
              <div>
              <hr style="width: 30%;float: left;margin-top: 13px;">
<p >&nbsp; Or Sign in with</p>
<hr style="width: 30%;float: right;margin-top: -26px">
</div>
            <div> 

                <button type="button" class="btn btn-default" style="width: 47%;color:black; border: 1px solid #0000000f;"><a href="#" class="fa fa-facebook"></a>  Facebook</button> &nbsp; 
               <button type="button" class="btn btn-default" style="width: 47%;color:black; border: 1px solid #0000000f;"><a href="#" class="fa fa-google"></a>  Google</button>
               <br>
                <br>
                <br>

                  <br>
             <p style="text-align: center;color: grey;"> 
           Don't have an account?<a href="Signin.php" style="color: black;font-weight: 700;text-decoration: none;">Sign Up</a></p>

          </div>
        </div>
      </div>
    </div>
  </div>

</div>
        



<script src="jbvalidator.min.js"></script>
<script>
    $(function (){

        let validator = $('form.needs-validation').jbvalidator({
            errorMessage: true,
            successClass: true,
            language: 'dist/lang/en.json'
        });

        //new custom validate methode
        

        
        //serverside
      
    })
</script>

      <script type="text/javascript">
    const password = document.getElementById("password");
const togglePassword = document.getElementById("toggle-password");

togglePassword.addEventListener("click", toggleClicked);

function toggleClicked() {
  password.classList.toggle("visible");
  if (this.checked) {
    password.type = "text";
  } else {
    password.type = "password";
  }
}
</script>      
     

    </body>
</html>
