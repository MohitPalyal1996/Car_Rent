<?php 
// require('js/custom.js');

include 'config.php';
if(isset($_POST['submit'])) {
	$Email = $_POST['Email'];
	$Password = $_POST['Password'];

	$search = "select * from adrenture_table where Email='$Email' ";
	$query = mysqli_query($con,$search);

	$email_count = mysqli_num_rows($query);


	if ($email_count) {
		$email_pass = mysqli_fetch_assoc($query);
		$db_pass = $email_pass['Password'];
		$_SESSION['Name'] = $email_pass['Name'];
		$pass_decode = password_verify($Password, $db_pass);

		if ($pass_decode) {
if (isset($_POST['rememberme'])) {

setcookie('emailcookie',$Email,time()+86400);
setcookie('passwordcookie',$Password,time()+86400);
	header('location:index.php');
}else{
	header('location:index.php');
}
echo "login successfull";
			header("Location:index.php");
		}else{ 
			echo'<script> alert("password Incorrect")</script>';
				//header("Location:login.php");
				header('location:login.php');
		
		}

	}

}


 ?>