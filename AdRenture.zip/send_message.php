<?php
  include('config.php');
if (isset($_POST['Submit'])) 
{
$NAME=mysqli_real_escape_string($con, $_POST['NAME']);
$EMAIL=mysqli_real_escape_string($con, $_POST['EMAIL']);
$MOBILE=mysqli_real_escape_string($con, $_POST['MOBILE']);
$COMMENT=mysqli_real_escape_string($con, $_POST['COMMENT']);
$added_on=date('y-m-d h:i:s');
$query="insert into adrenture_query(NAME,EMAIL,MOBILE,COMMENT,added_on) values ('$NAME','$EMAIL','$MOBILE','$COMMENT','$added_on')";

$run=mysqli_query($con,$query);
if($run)
{

  echo'<script> alert(" Thank you WE Will Connenct you Soon")</script>';
}

  else
  {
    echo'<script> alert("Please Again With Right Parameters")</script>';
  }
}

 ?>
 