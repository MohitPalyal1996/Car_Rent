<!DOCTYPE html>

<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/custom.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min">
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min">
<link rel="stylesheet" href="assets/hover">
<link rel="stylesheet" href="assets/animate.min">
<link rel="stylesheet" href="assets/revolution/css/settings">
<link rel="stylesheet" href="assets/owl.carousel-2/assets/owl.carousel">
<link rel="stylesheet" href="assets/owl.carousel-2/assets/owl.theme.default.min">
<link rel="stylesheet" href="assets/Stroke-Gap-Icons-Webfont/style">
<link rel="stylesheet" href="assets/jquery-ui-1.11.4/jquery-ui">
<link rel="stylesheet" href="assets/fancyapps-fancyBox/source/jquery.fancybox">


<style type="text/css">

input, label {
font-weight: 700;
display: inline-block;
color: white;

}

.form-group {
 
  width: 500px;

}

.form-control {
  float: left;
}

#inputStreet {
  width: 100%;

}

#inputCity {
  width: 50%;

}

#inputState {
  width: 50%;
}

#inputZip {
  width: 50%;
}

#inputCounty {
  width: 50%;
}




</style>
</head>
<body style="background-image: url(img/background.jpg); background-repeat: no-repeat;">

<h1 class="text-left " style="font-weight: 500;font-family: latin;color: black;font-size: 48px;text-shadow: 2px 1px;background-color:Chocolate;line-height: 80px;box-shadow: 0px 10px rgb(0,0,0,0.5)">&nbsp; &nbsp; &nbsp; AdRenture </h1>

<h1 class="text-center bg-dark text-white" style="font-weight: 500;font-family: latin">SIGN UP IN WEBSITE </h1>
	<div class="container">
		<div class="row">
		  
		<br>
		<form action="singincont.php" method="post"  onsubmit="return validation()" >
			<div class="form-group">
				<label >NAME:</label>
				<input type="text" name="Name" id="uname" class="form-control"placeholder="ex: abcd efgh" required >
				<span id="nameerror" class="text-danger font-weight-bold"></span>
			</div>
			<div class="form-group">
				<label>MOBILE NUMBER:</label>
				<input type="text" name="MobileNo" id="mob" class="form-control" placeholder="Enter Your Mobile" required>
				<span id="mobileerror" class="text-danger font-weight-bold"></span>
			</div>
			<div class="form-group">
				<label>EMAIL:</label>
				<input type="email" name="Email" id="eMAIL" class="form-control" placeholder="Enter Your Email" required>
				<span id="emailerror" class="text-danger font-weight-bold"></span>
			</div>
			<div class="form-group">
				<label>PASSWORD:</label>
				<input type="password" name="Password" id="password" class="form-control" placeholder="eg: Password should btw 8-15 chtr along with !@#$%^*" required>
				<span id="passerror" class="text-danger font-weight-bold"></span>
			</div>
<!-- <div class="form-group">
	<label>ADDRESS:</label>
  <textarea type="textarea" name="Address"  class="form-control" id="autocomplete" placeholder="Street,Village,PlotNo." required></textarea> 
  <select name="Country" id="inputCounty" class="form-control" placeholder="Country" required>
<option >country</option>
<option id="inputState" required >India</option></select>
<select name="State" id="inputState" class="form-control" id="" placeholder="State" required>
<option>State</option>
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Puducherry">Puducherry</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="West Bengal">West Bengal</option>
</select>
<input type="text"  name="City" class="form-control" id="inputCity" placeholder="City" required>
<input type="text"   name="PinCode" class="form-control" id="inputZip" placeholder="PinCode" required>



</div> -->
<br>
<br>
<div class="form-group" style="text-align: center;">
			<input type="submit" name="submit" class="btn btn-primary" >
		</div>
	<a href="login.php" class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Login</a>
		<a href="index.php" class="btn btn-success btn-lg active" role="button" aria-pressed="true">Back </a>

		</form>

	</div>
</div>
</div>

<script type="text/javascript">
	function validation(){

	var uname = document.getElementById('uname').value;
	var password = document.getElementById('password').value;
	var eMAIL = document.getElementById('eMAIL').value;
	var mob = document.getElementById('mob').value;

var namecheck = /^[A-Za-z. ]{3,14}$/ ;
var passcheck = /^(?=.*[0-9])(?=.*[!@#$%^*])[a-zA-Z0-9!@#$%^&*]{8,15}$/;
var emailcheck = /^[A-Za-z_.]{3,15}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;
var mobilecheck = /^[6789][0-9]{9}$/;

if(namecheck.test(uname)){
	document.getElementById('nameerror').innerHTML = " ";
}else{
	document.getElementById('nameerror').innerHTML ="**Name is NOT right";
	return false;
}

if(passcheck.test(password)){
	document.getElementById('passerror').innerHTML =" ";
}else{
	document.getElementById('passerror').innerHTML ="**PASSWORD is NOT Correct";
	return false;
}

 if (emailcheck.test(eMAIL)){
	document.getElementById('emailerror').innerHTML =" ";
}else{
	document.getElementById('emailerror').innerHTML ="**Email is NOT Correct";
	return false;
	
}
if (mobilecheck.test(mob)){
	document.getElementById('mobileerror').innerHTML =" ";
}else{
	document.getElementById('mobileerror').innerHTML ="**MOBILE-NUMBER is NOT Correct";
	return false;
}
}
</script>






</body>
</html>