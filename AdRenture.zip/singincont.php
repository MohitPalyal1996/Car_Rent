<?php
  include("config.php");
if (isset($_POST['submit'])) 
{
$Name=mysqli_real_escape_string($con, $_POST['Name']);
$MobileNo=mysqli_real_escape_string($con, $_POST['MobileNo']);
$Email=mysqli_real_escape_string($con, $_POST['Email']);
$Password=mysqli_real_escape_string($con, $_POST['Password']);


$Password = Password_hash($Password,PASSWORD_BCRYPT);


$emailquery =" select from adrenture_table where Email='$Email' ";
$query = mysqli_query($con,$emailquery);


$query="insert into adrenture_table(Name,Email,MobileNo,Password) values ('$Name','$Email','$MobileNo','$Password')";

$run=mysqli_query($con,$query);
if($run)
{
header("Location:login.php");
 
}

  else
  {
    echo'<script> alert("Please Again With Right Parameters")</script>';
  }
}

 ?>
 