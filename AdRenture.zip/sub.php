<?php 
session_start();
if($_POST){

$booked=$_POST['booking'];		
$captcha=$_POST['g-recaptcha-response'];
$secret="6LeuQE4UAAAAAHdptiTO0JFSsvndC0WRLSPVpY8X";
$action= file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");
$result= json_decode($action, TRUE);
if($result['success'])
{

$to = 'mikeymohit@gmail.com';
$subject = 'New booking form for hire car have been submitted';
$htmlContent = "
<h1>hire luxury car booking request details ".$booked."</h1>
<p><b>Name: </b>". $_POST['name']."</p>
<p><b>Email: </b>". $_POST['email']."</p>
<p><b>Mobile: </b>". $_POST['mob']."</p>
<p><b>Country: </b>". $_POST['country']."</p>
<p><b>State: </b>". $_POST['state']."</p>
<p><b>City: </b>". $_POST['city']."</p>
<p><b>Date of Arrival: </b>". $_POST['datea']."</p>
<p><b>Date of Departure: </b>". $_POST['dated']."</p>
<p><b>The Fleet: </b>". $_POST['acc']."</p>
<p><b>Travel City: </b>". $_POST['t_city']."</p>
<p><b>Address: </b>". $_POST['add']."</p>
<p><b>Comment: </b>".  $_POST['comment']."</p>

";
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
// More headers
$headers .= 'From:'. $_POST['name'].' <'.$_POST['email'].'>' . "\r\n";
//send email
if(mail($to,$subject,$htmlContent,$headers)){
echo '<section class="call-to-action" style="padding:10px;">
<div class="container">
<div class="row">
<div class="col-md-8">
<h2>Thanks You ! <b>'.$_POST['name'].'<b> </h2>
<h5 style="color:white;">A confirmation email has been sent to your provided email address.</h5>
</div>
<div class="col-md-4">
<div class="icon-box pull-right">
<a target="_blank" href="booknow.php" class="thm-btn hvr-sweep-to-top"><i class="fa fa-angle-right"></i>Book Now</a>
</div>
</div>
</div>
</div>
</section><br><br>'; 
}else{
echo " <h1>hire luxury car booking request details</h1>
<p><b>Name: </b>". $_POST['name']."</p>
<p><b>Email: </b>". $_POST['email']."</p>
<p><b>Mobile: </b>". $_POST['mob']."</p>
<p><b>Country: </b>". $_POST['country']."</p>
<p><b>State: </b>". $_POST['state']."</p>
<p><b>City: </b>". $_POST['city']."</p>
<p><b>Date of Arrival: </b>". $_POST['datea']."</p>
<p><b>Date of Departure: </b>". $_POST['dated']."</p>
<p><b>The Fleet: </b>". $_POST['acc']."</p>
<p><b>Travel City: </b>". $_POST['t_city']."</p>
<p><b>Address: </b>". $_POST['add']."</p>
<p><b>Comment: </b>".  $_POST['comment']."</p>"; 
}
}
else{
$_SESSION['flash_msg_c'] = "<p style='color:red'>* Robot verification failed. Please try again.</p><br>";
echo "<script>
window.setTimeout(function() {
window.location = 'booknow.php';
},0 );
</script>";
}
}



?>
