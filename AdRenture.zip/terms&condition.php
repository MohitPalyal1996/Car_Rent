<?php include_once 'include/header.php'; ?>
<section class="inner-banner" style="margin-top: 65px;">
		<div class="container text-center">
			<h2><span>Terms & Condition</span></h2>
			
		</div>
</section>
<section class="faq-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="accrodion-grps" >
					<div class="accrodion ">
						<ul>
							<li><p> Time and kilometers will be charged from garage to garage.</p></li>

							<li><p>Services for more than four hours will be charged under 80 kilometers and 8 hours.</p></li>

							<li><p>All parking charges , toll taxes , state taxes will be charged extra as per original receipts , in case taxes are paid in advance of any state 1/3rd tax will be charged of actual receipt.</p></li>

							<li><p> In package travel all parking charges , chauffeur charges , state taxes are inclusive.</p></li>

							<li><p>Service tax will be charged on gross invoice @ 4.12%, in case of payments by credit card additional 2% card charges will be charged .</p></li>

							<li><p>Once the vehicle leaves our garage, we will be charging for the same irrespective of being used or not.</p></li>

							<li><p>Once the vehicle leaves our garage, we will be charging for the same irrespective of being used or not.</p></li>

							<li><p> If there's an AC failure , AC rates will be charged up to the point of AC failure , further from that point we will be liable to compensate a maximum of 15% on further running.</p></li>

							<li><p> All the payments have to be made within 30 days after the presentation of the invoices. Any delay beyond this will attract a levy / interest of 2% per month.</p></li>

							<li><p> In case of any complaint we must be informed at that time only to enable us to resolve immediately . Complaints after taking the services will not be entertained at all . Our office is 24 hours open to take care of any emergency or complaint.</p></li>

							<li><p> Any delay in arriving in Delhi because of natural calamities or disasters will be borne by the client i.e. landslides , earthquake , floods etc.</p></li>

							<li><p> We are not liable to pay any compensation due to technical failure in vehicle or because of any accident resulting to loss of productivity or loss of working man hours. All our vehicles are comprehensively insured all such claims must be pursued with our insurance company only.</p></li>

							<li><p> We will not be responsible for any luggage or any things left by the client in the vehicle, if found later will be delivered at the client's address with extra charges.</p></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<section>
		<div class="row">
			<div class="container">
					<p style="color: #FF3720;">Cancellation charges will be charged as follows for all the premium and luxury vehicles :</p>
							<ol>
								<li>
									30 days prior to departure - 10% of the gross amount or a minimum of 1 day charges.
								</li>
								<li>
									15 days prior to departure - 25% of the gross amount or a minimum of 1 day charges.
								</li>
								<li>
									2 days prior to departure - 50% of the gross amount or a minimum of 1 day charges.
								</li>
								<li>
									No show or last minute - 100 % of the gross amount will be charged.
								</li>
							</ol><br><br>
							<ul>
								<li>
									For your own safety , all our chauffeurs will take a nap/rest of up to 15 minutes after continues two hours driving and a nap/rest of 15 to 30 minutes after continuous four hours driving.
								</li>
								<li>
									No eatables, alcoholic beverages ,tea ,coffee etc. will be allowed while the coach/car is moving.
								</li>
								<li>
									Any breakage/damage to the coach /car due to negligence/mishandling by the clients will be borne by the traveling person or related company only.
								</li>
								<li>
									All prices/packages are subject to change in Petroleum prices or state taxes without intimation.
								</li>
								<li>
									Any legal dispute subject to jurisdiction in Delhi only.
								</li>
							</ul>
			</div>
		</div>
	</section>
</section> <br><br>
<?php include_once 'include/footer.php'; ?>